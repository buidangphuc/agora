export const primitives = {
  color: {
    white: "#ffffff",
    "primary-50": "#eef2ff",
    "primary-100": "#e0e7ff",
    "primary-200": "#c7d2fe",
    "primary-300": "#a5b4fc",
    "primary-400": "#818cf8",
    "primary-500": "#6366f1",
    "primary-600": "#4f46e5",
    "primary-700": "#4338ca",
    "primary-800": "#3730a3",
    "primary-900": "#312e81",
    "primary-950": "#1e1b4b",
    "neutral-50": "#f8fafc",
    "neutral-100": "#f1f5f9",
    "neutral-200": "#e2e8f0",
    "neutral-300": "#cbd5e1",
    "neutral-400": "#94a3b8",
    "neutral-500": "#64748b",
    "neutral-600": "#475569",
    "neutral-700": "#334155",
    "neutral-800": "#1e293b",
    "neutral-900": "#0f172a",
    danger: "#dc2626",
    "danger-dark": "#b91c1c",
    "danger-light": "#fca5a5",
    scrim: "#11182799",
    promo: "#fbbf24",
    "promo-dark": "#92400e",
    success: "#10b981",
    "success-dark": "#047857",
  },
  space: {
    0: 0,
    1: 4,
    2: 8,
    3: 12,
    4: 16,
    5: 20,
    6: 24,
    8: 32,
    10: 40,
    12: 48,
    16: 64,
    18: 72,
  },
  radius: {
    none: 0,
    xs: 2,
    lg: 8,
    xl: 12,
    "2xl": 16,
    "3xl": 24,
    full: 9999,
  },
  fontSize: {
    xs: [12, 16],
    sm: [14, 20],
    base: [16, 24],
    xl: [20, 28],
    "2xl": [24, 32],
    "3xl": [30, 36],
    "4xl": [36, 40],
  },
  fontFamily: {
    sans: [
      "Inter",
      "ui-sans-serif",
      "system-ui",
      "-apple-system",
      "Segoe UI",
      "Roboto",
      "sans-serif",
    ],
  },
  breakpoint: { sm: 640, md: 768, lg: 1024 },
  touchTarget: 44,
};

export const shadow = {
  light: {
    card: [
      { x: 0, y: 1, blur: 2, spread: 0, color: "#0f172a0f" },
      { x: 0, y: 4, blur: 16, spread: 0, color: "#0f172a0a" },
    ],
    pop: [
      { x: 0, y: 4, blur: 8, spread: 0, color: "#0f172a14" },
      { x: 0, y: 16, blur: 40, spread: 0, color: "#0f172a1f" },
    ],
  },
  dark: {
    card: [
      { x: 0, y: 1, blur: 2, spread: 0, color: "#00000066" },
      { x: 0, y: 4, blur: 16, spread: 0, color: "#00000040" },
    ],
    pop: [
      { x: 0, y: 4, blur: 8, spread: 0, color: "#00000080" },
      { x: 0, y: 16, blur: 40, spread: 0, color: "#00000099" },
    ],
  },
};

export const semantic = {
  light: {
    "action-primary": "primary-600",
    "action-primary-hover": "primary-700",
    "surface-page": "neutral-50",
    "surface-card": "white",
    "surface-muted": "neutral-100",
    "border-subtle": "neutral-200",
    "border-strong": "neutral-300",
    "border-danger": "danger-dark",
    "surface-overlay": "scrim",
    "text-primary": "neutral-900",
    "text-secondary": "neutral-600",
    "text-disabled": "neutral-400",
    "text-inverse": "white",
    "text-link": "primary-700",
    "text-link-hover": "primary-800",
    "text-danger": "danger-dark",
    "text-success": "success-dark",
    "text-warning": "promo-dark",
    "focus-ring": "primary-600",
  },
  dark: {
    "action-primary": "primary-600",
    "action-primary-hover": "primary-700",
    "surface-page": "neutral-900",
    "surface-card": "neutral-800",
    "surface-muted": "neutral-700",
    "border-subtle": "neutral-700",
    "border-strong": "neutral-600",
    "border-danger": "danger-light",
    "surface-overlay": "scrim",
    "text-primary": "neutral-50",
    "text-secondary": "neutral-300",
    "text-disabled": "neutral-500",
    "text-inverse": "white",
    "text-link": "primary-300",
    "text-link-hover": "primary-200",
    "text-danger": "danger-light",
    "text-success": "success",
    "text-warning": "promo",
    "focus-ring": "primary-400",
  },
};

export const components = {
  button: {
    base: "inline-flex items-center justify-center gap-2 rounded-xl font-sans font-semibold min-h-touch focus-visible:ring-2 focus-visible:ring-focus-ring",
    variant: {
      primary:
        "bg-action-primary text-text-inverse hover:bg-action-primary-hover shadow-card",
      secondary:
        "bg-surface-card text-text-primary border border-border-strong hover:bg-surface-muted",
      ghost: "text-text-primary hover:bg-surface-muted",
    },
    size: {
      sm: "px-4 py-2 text-sm",
      md: "px-6 py-3 text-base",
      lg: "px-8 py-4 text-base",
    },
    disabled: "text-text-disabled",
  },
  field: {
    label: "block text-sm font-semibold text-text-primary",
    help: "text-sm text-text-secondary",
    error: "text-sm text-text-danger",
  },
  input: {
    base: "w-full rounded-xl border border-border-strong bg-surface-card text-text-primary text-base px-4 py-3 min-h-touch focus-visible:ring-2 focus-visible:ring-focus-ring",
    invalid: "border-border-danger",
    disabled: "bg-surface-muted text-text-disabled",
  },
  select: {
    trigger:
      "inline-flex w-full items-center justify-between rounded-xl border border-border-strong bg-surface-card text-text-primary text-base px-4 py-3 min-h-touch focus-visible:ring-2 focus-visible:ring-focus-ring",
    content:
      "rounded-2xl border border-border-subtle bg-surface-card text-text-primary p-2 shadow-pop",
    item: "flex items-center rounded-lg px-4 py-3 min-h-touch text-base text-text-primary",
  },
  checkbox: {
    row: "flex items-center gap-3 min-h-touch",
    root: "h-6 w-6 rounded-lg border border-border-strong bg-surface-card text-text-inverse focus-visible:ring-2 focus-visible:ring-focus-ring",
    checked: "aria-checked:bg-action-primary",
  },
  dialog: {
    overlay: "fixed inset-0 bg-surface-overlay",
    content:
      "fixed rounded-2xl bg-surface-card text-text-primary border border-border-subtle p-6 shadow-pop",
    title: "text-2xl font-semibold text-text-primary",
    description: "text-base text-text-secondary",
  },
  toast: {
    root: "rounded-2xl border border-border-subtle bg-surface-card text-text-primary p-4 shadow-pop",
    title: "text-base font-semibold text-text-primary",
    description: "text-sm text-text-secondary",
  },
  table: {
    root: "w-full text-base text-text-primary",
    caption: "p-4 text-left text-sm text-text-secondary",
    th: "border-b border-border-strong p-4 text-left text-sm font-semibold text-text-secondary",
    td: "border-b border-border-subtle p-4",
    empty: "p-8 text-center text-text-secondary",
  },
  link: {
    base: "text-text-link underline underline-offset-4 hover:text-text-link-hover rounded-lg focus-visible:ring-2 focus-visible:ring-focus-ring",
  },
  card: {
    base: "rounded-2xl bg-surface-card border border-border-subtle p-6 shadow-card",
  },
};
