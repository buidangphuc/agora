import { components } from "@fe-platform/tokens";
import type { ReactNode } from "react";
import { cx } from "./cx";
import type { NativeProps } from "./types";

const { button } = components;

export type ButtonProps = NativeProps<"button"> & {
  variant?: keyof typeof button.variant;
  size?: keyof typeof button.size;
  loading?: boolean;
  fullWidth?: boolean | "mobile";
  leftIcon?: ReactNode;
  rightIcon?: ReactNode;
};

/** Action trigger. One `primary` per view; `ghost` for low-emphasis actions; `danger` for destructive ones; `fullWidth="mobile"` is full width below the sm breakpoint only; `loading` keeps the idle width. */
export function Button({
  variant = "primary",
  size = "md",
  loading = false,
  fullWidth = false,
  leftIcon,
  rightIcon,
  disabled,
  type = "button",
  children,
  ...rest
}: ButtonProps) {
  const inactive = disabled || loading;
  return (
    <button
      {...rest}
      type={type}
      disabled={inactive}
      aria-busy={loading || undefined}
      className={cx(
        button.base,
        button.variant[variant],
        button.size[size],
        fullWidth === "mobile"
          ? button.fullWidthMobile
          : fullWidth && button.fullWidth,
        inactive && button.disabled,
      )}
    >
      <span className={cx(button.content, loading && button.contentLoading)}>
        {leftIcon && <span className={button.icon}>{leftIcon}</span>}
        {children}
        {rightIcon && <span className={button.icon}>{rightIcon}</span>}
      </span>
      {loading && (
        <span aria-hidden="true" className={button.spinnerSlot}>
          <span className={button.spinner} />
        </span>
      )}
    </button>
  );
}
